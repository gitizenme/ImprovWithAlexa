**To create an application**

This example creates an application and associates it with the user's AWS account.

Command::

  aws deploy create-application --application-name MyOther_App
  
Output::

  {
      "applicationId": "cfd3e1f1-5744-4aee-9251-eaa25EXAMPLE"
  }